#!/usr/bin/env python3
"""Create a deterministic, read-only SHA-256 inventory of an evidence folder."""

from __future__ import annotations

import argparse
import hashlib
import json
import mimetypes
import os
import stat
import sys
from datetime import datetime, timezone
from pathlib import Path


CHUNK_SIZE = 1024 * 1024


def utc_iso(timestamp: float) -> str:
    return datetime.fromtimestamp(timestamp, tz=timezone.utc).isoformat().replace("+00:00", "Z")


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(CHUNK_SIZE), b""):
            digest.update(chunk)
    return digest.hexdigest()


def inventory(root: Path, output: Path) -> tuple[list[dict[str, object]], list[dict[str, str]]]:
    records: list[dict[str, object]] = []
    errors: list[dict[str, str]] = []
    output_resolved = output.resolve(strict=False)

    for current_dir, dirnames, filenames in os.walk(root, followlinks=False):
        current = Path(current_dir)
        dirnames[:] = sorted(
            [name for name in dirnames if not (current / name).is_symlink()],
            key=str.casefold,
        )

        for name in sorted(filenames, key=str.casefold):
            path = current / name
            relative = path.relative_to(root).as_posix()

            try:
                if path.resolve(strict=False) == output_resolved:
                    continue

                details = path.lstat()
                if stat.S_ISLNK(details.st_mode):
                    records.append(
                        {
                            "relative_path": relative,
                            "entry_type": "symlink",
                            "link_target": os.readlink(path),
                            "size_bytes": details.st_size,
                            "mtime_utc": utc_iso(details.st_mtime),
                            "sha256": None,
                            "mime_type": None,
                        }
                    )
                    continue

                if not stat.S_ISREG(details.st_mode):
                    records.append(
                        {
                            "relative_path": relative,
                            "entry_type": "other",
                            "size_bytes": details.st_size,
                            "mtime_utc": utc_iso(details.st_mtime),
                            "sha256": None,
                            "mime_type": None,
                        }
                    )
                    continue

                records.append(
                    {
                        "relative_path": relative,
                        "entry_type": "file",
                        "size_bytes": details.st_size,
                        "mtime_utc": utc_iso(details.st_mtime),
                        "sha256": sha256_file(path),
                        "mime_type": mimetypes.guess_type(path.name)[0]
                        or "application/octet-stream",
                    }
                )
            except (OSError, ValueError) as exc:
                errors.append(
                    {
                        "relative_path": relative,
                        "error": f"{type(exc).__name__}: {exc}",
                    }
                )

    records.sort(key=lambda item: str(item["relative_path"]).casefold())
    errors.sort(key=lambda item: item["relative_path"].casefold())
    return records, errors


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Recursively inventory regular files and compute SHA-256 hashes."
    )
    parser.add_argument("evidence_root", type=Path, help="Evidence directory to read")
    parser.add_argument(
        "--output", required=True, type=Path, help="JSON manifest path to create or replace"
    )
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    root = args.evidence_root.expanduser().resolve()
    output = args.output.expanduser().resolve(strict=False)

    if not root.is_dir():
        print(f"error: evidence root is not a directory: {root}", file=sys.stderr)
        return 2
    if output == root or output.is_dir():
        print("error: --output must be a JSON file path", file=sys.stderr)
        return 2

    records, errors = inventory(root, output)
    payload = {
        "schema_version": 1,
        "generated_at_utc": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
        "root_name": root.name,
        "hash_algorithm": "sha256",
        "file_count": sum(item["entry_type"] == "file" for item in records),
        "entry_count": len(records),
        "error_count": len(errors),
        "entries": records,
        "errors": errors,
    }

    output.parent.mkdir(parents=True, exist_ok=True)
    temporary = output.with_name(f".{output.name}.tmp-{os.getpid()}")
    try:
        with temporary.open("w", encoding="utf-8", newline="\n") as handle:
            json.dump(payload, handle, ensure_ascii=False, indent=2)
            handle.write("\n")
        os.replace(temporary, output)
    except OSError as exc:
        try:
            temporary.unlink(missing_ok=True)
        except OSError:
            pass
        print(f"error: could not write manifest: {exc}", file=sys.stderr)
        return 1

    print(
        f"manifest written: {output} "
        f"({payload['file_count']} files, {payload['error_count']} errors)"
    )
    return 1 if errors else 0


if __name__ == "__main__":
    raise SystemExit(main())
