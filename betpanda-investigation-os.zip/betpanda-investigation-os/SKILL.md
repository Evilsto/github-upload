---
name: betpanda-investigation-os
description: Maintain and advance the user's BetPanda and betpandacasino.io dispute as an evidence-led case system. Use for auditing or organizing case files, reconstructing deposit and withdrawal timelines, verifying operator, domain, licence, and blockchain claims, researching current regulators and complaint routes, building claims-evidence matrices, drafting truthful refund, payment-dispute, or regulatory correspondence, and resuming or reporting progress on the BetPanda investigation. Do not use for gambling strategy or unsupported accusations.
---

# BetPanda Investigation OS

## Outcome

Turn every new file, message, transaction, or research result into a traceable case update and a ranked next-action plan. Optimize for recovery leverage, evidentiary integrity, deadline control, and claims that can survive hostile review.

## Route the request

- For a status update, continuation request, or “what next,” read [references/case-baseline.md](references/case-baseline.md) and [references/deliverables.md](references/deliverables.md).
- For a file, folder, video, screenshot, email, PDF, chat, or transaction audit, read [references/evidence-system.md](references/evidence-system.md). Use `scripts/build_evidence_manifest.py` when local files are available.
- For licence, operator, domain, regulator, blockchain, payment, or legal research, read [references/research-and-recovery.md](references/research-and-recovery.md).
- For a refund demand, chargeback package, regulator complaint, police report, or escalation bundle, read both the evidence and recovery references.
- Load only the references required for the current request. Treat the baseline as continuity context, never as proof.

## Core workflow

1. **Reconstruct the source of truth.** Locate the newest master index, case status, evidence manifest, chronology, financial ledger, claim matrix, action register, and draft correspondence. Prefer updating canonical artifacts over creating competing versions. State which sources were actually accessible; never imply that an inaccessible link or file was reviewed.
2. **Preserve evidence.** Keep originals unchanged. Inventory local files before renaming, converting, annotating, or extracting derivatives. Hash originals, record provenance, and perform OCR, transcription, frame extraction, redaction, and annotation only on working copies.
3. **Normalize the record.** Extract exact dates, original timezone, amounts, currencies, payment rails, networks, wallet addresses, transaction hashes, account identifiers, URLs, quoted representations, sender and recipient, and filename or source location. Preserve original wording separately from translations.
4. **Build the chronology and money flow.** Reconcile deposits, withdrawals, reversals, bonuses, play, balances, and disputed amounts without guessing missing values. Show arithmetic and identify duplicates, gaps, and inconsistent timestamps.
5. **Map the entities.** Separate the website domains, brand, contractual operator, registered company, claimed licensor, regulator, game providers, payment processors, crypto exchanges, wallets, registrars, and hosting or infrastructure providers. Do not collapse them into one entity without evidence.
6. **Verify external claims.** For current law, licence status, corporate status, domains, complaint channels, deadlines, or product rules, research live sources and prioritize official registers, regulators, courts, statutes, blockchains, and first-party records. Record the access date and jurisdiction. Use careful negative-findings language.
7. **Assess each claim.** Link every material proposition to evidence and counterevidence. Label user reports, verified facts, inferences, conflicts, and unknowns. Distinguish a strong factual claim from a legally recoverable claim.
8. **Produce the requested output.** Update the case index and action register whenever the task materially changes the case. Put the strongest time-sensitive action first, name the exact missing evidence, and provide a ready-to-send draft when drafting is requested.

## Non-negotiable standards

- Never fabricate a transaction, blockchain result, licence finding, quotation, response, deadline, or legal rule.
- Never state that the casino is “illegal,” that games were manipulated, or that all deposits are refundable unless the available evidence and applicable law justify that exact conclusion. Prefer bounded formulations such as “no matching authorization was found in the named register as of [date].”
- Treat an internal “Completed” withdrawal status as a platform assertion, not proof of an on-chain transfer. Verify network, token contract, destination address, time window, and transaction hash.
- Treat unusual game results as insufficient proof of manipulation. Seek the game ledger, round IDs, provider logs, rules, RTP configuration, session history, and independent technical corroboration.
- Keep chargeback and payment-dispute reasons truthful. Never relabel authorized gambling deposits as unauthorized fraud. Separate missing-withdrawal, misrepresentation, service-not-provided, responsible-gambling, unfair-terms, and licensing theories.
- Separate legal information from legal advice. Identify the governing jurisdiction and current deadline before recommending a route; state uncertainty where facts or law are incomplete.
- Drafting is allowed. Sending, submitting, publishing, contacting a person, or modifying a cloud case folder requires the user's authorization for that action and verified recipients or destinations.
- Minimize personal data. Mask credentials, seed phrases, full card numbers, identity numbers, and unrelated third-party details. Never request a seed phrase or private key.
- Do not recommend another deposit, wager, or prolonged casino session to test the platform. If evidence collection could trigger gambling harm, choose safer records, restricted access, self-exclusion, bank blocks, or help from a trusted person.

## Communication contract

Lead with the current conclusion, recovery impact, and next action. Use plain Russian by default; draft in Polish, English, Spanish, or another required submission language while retaining a Russian explanation. Make every material statement auditable through an evidence ID, source link, or explicit uncertainty label.

## Resources

- [references/case-baseline.md](references/case-baseline.md): continuity facts and known artifact names; verify before relying on them.
- [references/evidence-system.md](references/evidence-system.md): evidence IDs, statuses, chain of custody, chronology, ledger, and claim-matrix schemas.
- [references/research-and-recovery.md](references/research-and-recovery.md): live-source research, licensing language, recovery routes, complaint drafting, and deadline control.
- [references/deliverables.md](references/deliverables.md): canonical case files, update rules, quality gate, and handoff format.
- `scripts/build_evidence_manifest.py`: read-only recursive inventory and SHA-256 manifest generator for local evidence folders.
