# Research and recovery workflow

## Live research standard

Use current sources whenever a fact can change, including licence status, operator identity, company status, domain ownership, terms, complaint routes, addresses, deadlines, and bank or card-scheme rules.

Prioritize sources in this order:

1. Statutes, official gazettes, court or regulator decisions, official licence and company registers, and public blockchains.
2. The relevant regulator, bank, payment provider, card scheme, crypto exchange, registrar, game provider, or operator.
3. Reputable independent reporting or technical research with named methodology.
4. Aggregators, forums, mirrors, social posts, and review sites only as leads.

Record the query, jurisdiction, result URL, access timestamp, relevant excerpt in paraphrase, and limitations. Preserve historical captures when a current page may differ from the page shown when the account or transaction was created.

## Entity and licence map

Build a table with:

`entity_id`, `name`, `role`, `domain`, `company_number`, `jurisdiction`, `address`, `licence_claim`, `licence_number`, `licensor_or_regulator`, `verified_scope`, `effective_dates`, `source`, `accessed_at`, `conflicts`, `next_check`.

Test each licence claim separately:

- Does the issuing body exist and have the claimed authority?
- Does the number exist in its official record?
- Who holds it?
- Which company, brand, domains, products, and dates does it cover?
- Was the displayed statement materially different at the time of play or payment?
- Did the authority confirm only registration, data processing, or another status rather than a gambling licence?

Use bounded wording for negative findings: “No entry matching [entity/domain/number] was located in [named official register] using [queries] as of [UTC timestamp].” Do not convert one register search into a universal conclusion.

## Claim-specific proof tests

| Theory | Strong supporting proof | Frequent weakness |
|---|---|---|
| Missing crypto withdrawal | Platform withdrawal record, exact address/network/token, no matching on-chain transfer, exchange confirmation, support refusal to provide TXID | Wrong chain, incomplete address history, internal status treated as blockchain proof |
| Licence or operator misrepresentation | Historical page or terms, exact representation, official issuer response/register, domain and holder mismatch, material reliance | Current page used for a past claim, ambiguous “licence” terminology, no link to loss or remedy |
| Ledger or access failure | Dated data-access or ledger requests, scope, delivery deadline, refusal or incomplete export | No proof of request or unclear requested data |
| Responsible-gambling failure | Self-exclusion or limit request, vulnerability notice, continued access, inducements, deposits after notice | General losses without notice, duty, causation, or time linkage |
| Unfair terms or withheld funds | Applicable terms version, balance and withdrawal eligibility, reason given, KYC record, inconsistent enforcement | Bonus or wagering terms omitted, wrong contract version |
| Game manipulation | Round IDs, provider logs, certified game rules/configuration, reproducible discrepancy, independent expert evidence | Suspicion based only on losses, visual animation, or expected RTP |

## Recovery routes

Choose routes by evidence, jurisdiction, payment rail, deadline, cost, and realistic remedy. Parallel routes are allowed when truthful and non-duplicative.

1. **Preservation and formal demand.** Request the account ledger, game and round history, deposit and withdrawal ledger, KYC decision log, communications, terms version, operator identity, licence basis, and exact blockchain transaction data. Set a reasonable response date and preserve delivery proof.
2. **Bank, card, or payment-provider dispute.** Verify the payment rail and deadline. Use the exact factual category supported by the evidence. Attach a transaction schedule and proof of attempted resolution. Disclose authorized deposits; do not falsely describe them as stolen-card transactions.
3. **Crypto exchange support or compliance.** Request transaction-history confirmation and preserve account statements. Recognize that exchange support may document non-receipt but generally cannot reverse a completed external transfer.
4. **Gambling or licensing authority.** Confirm that the authority covers the operator, holder, domain, date, and complaint type. If jurisdiction is disputed, ask the alleged issuer to confirm scope in writing.
5. **Consumer, data-protection, cybercrime, or financial-crime channel.** Use only the channel matching the facts and legal scope. A data-access complaint, fraud report, and consumer claim prove different things and offer different remedies.
6. **Civil claim or counsel review.** Package parties, jurisdiction, terms, amount, chronology, service details, evidence, limitation periods, and enforcement feasibility. Do not imply that a favorable judgment is easy to enforce against an unidentified offshore operator.
7. **Registrar, host, platform, or advertising report.** Treat as disruption or preservation leverage, not a direct refund route, unless that provider offers a specific remedy.

## “All deposits” analysis

Calculate at least three figures separately:

- Gross deposits in the relevant period.
- Net loss after confirmed withdrawals, refunds, and reversals.
- Amount tied to each specific theory and cutoff date.

Then assess entitlement theory by theory. A missing withdrawal claim can be strong without making every earlier deposit refundable. A licence or consumer-law argument may broaden the claim, but only if the applicable law, misrepresentation, causation, and remedy support it. State the maximum asserted amount and the more defensible evidence-backed amount separately when they differ.

## Drafting protocol

Every external draft must include:

1. Correct recipient and basis for jurisdiction.
2. Account identifier with unnecessary personal data masked.
3. Short numbered chronology.
4. Precise allegations framed as facts, reports, or unresolved questions.
5. Transaction table and evidence references.
6. Exact requested remedies and records.
7. Response deadline grounded in contract, law, policy, or a clearly stated reasonable request.
8. Preservation notice where relevant.
9. Attachment index.
10. Reservation of rights without threats or inflated criminal accusations.

Draft in the recipient's working language when useful, and provide the user a Russian explanation. Quote source material sparingly and exactly. Do not cite a case, statute, regulator, card rule, or deadline without current verification.

## Prioritization

Score actions using:

`priority = evidence_strength × remedy_value × deadline_urgency × recipient_fit ÷ cost_and_risk`

Use qualitative `HIGH`, `MEDIUM`, or `LOW` scores if numeric assumptions would create false precision. Put expiring bank or statutory deadlines ahead of low-probability reputational reports. Identify dependencies and the single next action that unlocks the most routes.
