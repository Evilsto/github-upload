# Evidence and claim system

## Core distinction

Maintain four separate layers:

1. **Artifact:** the original file, message, record, webpage, or blockchain observation.
2. **Event:** what happened, when, between whom, and for what amount or account.
3. **Claim:** a proposition that may support a remedy or rebuttal.
4. **Conclusion:** the current assessment after evidence and counterevidence are weighed.

Never promote a user report, filename, or summary into a verified fact without inspecting its source.

## Identifiers

Assign stable IDs and never recycle them:

- Evidence: `BP-EV-YYYYMMDD-NNN`
- Event: `BP-EVT-YYYYMMDD-NNN`
- Claim: `BP-CLM-NNN`
- Action: `BP-ACT-NNN`
- Correspondence: `BP-COR-YYYYMMDD-NNN`

Use the evidence creation or receipt date when known; otherwise use the inventory date and record the original date as unknown.

## Evidence status

Use exactly one primary status and explain any limitation:

| Status | Meaning |
|---|---|
| `ORIGINAL_VERIFIED` | Original or authoritative record inspected and integrity data captured. |
| `DERIVATIVE_VERIFIED` | Working copy, export, transcript, OCR, or screenshot tied to an original. |
| `EXTERNAL_VERIFIED` | Official register, blockchain, statute, regulator, court, or first-party external record checked live. |
| `CORROBORATED` | Material point supported by at least two independent sources. |
| `USER_REPORTED` | User statement not yet verified from an artifact. |
| `INFERENCE` | Reasoned conclusion explicitly derived from identified facts. |
| `DISPUTED` | Credible sources conflict. |
| `INCOMPLETE` | Artifact exists but key context, pages, headers, metadata, or adjacent records are missing. |
| `NOT_FOUND` | A defined search found no result; this is not proof that the thing never existed. |

## Evidence register fields

Record at least:

`evidence_id`, `title`, `type`, `source_or_sender`, `recipient`, `original_filename_or_url`, `date_created`, `date_received`, `timezone`, `sha256`, `size_bytes`, `storage_location`, `status`, `language`, `account_or_transaction_refs`, `what_it_supports`, `limitations`, `derivative_of`, `reviewed_at`, `notes`.

For cloud artifacts, record provider ID, path, revision or version, owner, shared-link state, and export date when available. A shared link is a locator, not chain-of-custody proof.

## Preservation rules by artifact type

### Email

Prefer `.eml` or another export containing full headers. Treat a PDF print or screenshot as a derivative. Capture sender, recipient, subject, sent time, Message-ID, authentication results if present, attachments, and the complete thread context.

### Screenshot and webpage

Capture the full screen where possible, URL, access time, account context, visible status, and surrounding navigation. Preserve the raw screenshot. Record whether the page was authenticated, dynamic, or historical. Save official-page text and a visual capture when the representation is material.

### Video and screen recording

Hash the original before conversion. Record duration, dimensions, codec, creation metadata, and gaps. Create a timestamped transcript or event log. Extract only relevant frames as derivatives and link each frame to the original timestamp. Do not claim activity outside the visible recording.

### PDF

Preserve the source PDF. Inspect both extracted text and rendered pages. Record missing pages, broken signatures, hidden attachments, OCR use, and whether it is an original digital document or a print-to-PDF derivative.

### Blockchain and crypto

Record chain, network, token symbol, token contract, transaction hash, source and destination addresses, amount in base units and display units, block number, timestamp, status, confirmations, fee, explorer URL, and access time. Distinguish native assets from tokens and distinguish similarly named networks. A search by the wrong network or address cannot support an absence claim.

### Chats and account exports

Capture the complete thread or export, participant identities, timestamps, account identifier, and surrounding context. Treat manually copied snippets as incomplete unless reconciled to the original.

## Chronology schema

Use one row per event:

`event_id`, `occurred_at_original`, `timezone_original`, `occurred_at_utc`, `event_type`, `actor`, `counterparty`, `account`, `amount`, `currency_or_token`, `network_or_rail`, `transaction_or_round_id`, `description`, `evidence_ids`, `confidence`, `conflict_notes`.

Never force ambiguous timestamps into an exact order. Preserve a range or `unknown` and identify the evidence needed to resolve it.

## Financial ledger schema

Use one row per movement or asserted movement:

`ledger_id`, `timestamp_utc`, `direction`, `category`, `amount`, `currency`, `fiat_value_at_time`, `account`, `merchant_descriptor`, `payment_method`, `network`, `platform_transaction_id`, `external_transaction_id`, `status_platform`, `status_external`, `evidence_ids`, `duplicate_group`, `recovery_theory`, `notes`.

Keep gross deposits, withdrawals requested, withdrawals received, bonuses, reversals, chargebacks, and net loss as separate metrics. Do not equate gross deposits with recoverable damages.

## Claim matrix schema

Use one row per proposition:

`claim_id`, `precise_proposition`, `remedy_or_relevance`, `supporting_evidence_ids`, `counterevidence_ids`, `status`, `confidence`, `jurisdiction`, `legal_or_contract_basis`, `deadline`, `missing_proof`, `next_test`, `safe_external_wording`.

Confidence must reflect both source quality and completeness:

- `HIGH`: direct, authenticated evidence and no material unresolved conflict.
- `MEDIUM`: credible support with a meaningful gap or plausible alternative explanation.
- `LOW`: mainly user report, derivative material, ambiguous negative search, or substantial conflict.

## Contradictions and duplicates

- Preserve both versions of a contradiction and add a resolution action.
- Use hashes for byte-identical duplicates and visual or content comparison for transformed copies.
- Do not delete duplicates merely because they appear redundant; designate a canonical original and retain provenance.
- Flag edited images, cropped screenshots, incomplete threads, mismatched timezones, inconsistent amounts, and filenames that do not match embedded dates.

## Manifest script

Run:

```bash
python3 scripts/build_evidence_manifest.py /path/to/evidence \
  --output /path/to/working/evidence-manifest.json
```

The script reads files recursively, does not follow directory symlinks, hashes regular files with SHA-256, and writes one explicit JSON output. Review reported errors and add evidence IDs separately; the script does not decide evidentiary value.
