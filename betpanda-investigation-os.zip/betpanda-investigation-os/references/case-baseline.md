# BetPanda case baseline

Use this file only to restore continuity and locate source material. The entries below are prior user reports, not independently verified facts and not evidence by themselves. Replace or qualify them after inspecting the underlying records.

## Current objective

- Seek recovery of all legally supportable losses or deposits, with missing withdrawals and possible misrepresentation as priority theories.
- Build regulator-, bank-, payment-provider-, law-enforcement-, and counsel-ready evidence packages.
- Continue the investigation without repeating completed work or weakening credible claims through overstatement.

## Reported case assertions

- Relevant brand or domains: `betpandacasino.io` and `betpanda.io`.
- The user reported that one or more USDC withdrawals were marked “Completed” by the platform but no blockchain transaction hash was provided.
- The user reported that Coinbase confirmed no matching incoming USDC transfers for the relevant dates.
- The user reported that support declined or failed to provide the transaction hash and destination or source details.
- The user reported receiving a response connected to Costa Rica case `CS0064741`, which allegedly indicated that the displayed licence number related to another platform and did not cover the named BetPanda domains.
- The user reported that the casino refused to provide a complete account or game ledger.
- The user suspects bet or game manipulation, but the baseline contains no provider ledger or independent technical proof establishing manipulation.
- The user reported Platinum VIP status and slot-only play. Verify whether either fact has legal or evidentiary relevance before using it.
- The user is based in Poland according to prior context. Verify residence, account-registration country, contracting terms, payment origin, and transaction dates before choosing jurisdiction.

## Known artifact leads

- `BETPANDA_MASTER_CASE_INDEX_2026-09-02.md`
- `Gmail - Actualización del caso número CS0064741.pdf`
- `Nagrywanie.mp4`
- `Nagrywanie ekranu 2026-07-10 234903 (1).mp4`
- `Nagrywanie 2026-07-10 235844 (1).mp4`
- Screenshots of account, VIP status, deposits, withdrawals, and support chats
- Coinbase correspondence or account records concerning the allegedly missing USDC transfers
- Block-explorer links or searches supplied in earlier work
- A user-provided Dropbox case folder and earlier ChatGPT share links

Do not say these files or links were reviewed unless they are accessible in the current task. Search available case storage for newer versions and additional originals.

## High-priority unresolved facts

1. Exact disputed withdrawal IDs, amounts, currencies, timestamps, network, token contract, destination address, and platform status history.
2. Complete deposit ledger and total sought under each recovery theory, excluding duplicates and distinguishing net loss from gross deposits.
3. Contracting entity and terms accepted at each material date.
4. Exact licence representation, licence number, issuing body, domain coverage, and historical page capture.
5. Full original regulator response, sender authenticity, translation, attachments, and the question it answered.
6. Payment processors, merchant descriptors, card or bank rails, crypto exchanges, and applicable dispute deadlines.
7. Complete support escalation history, including ledger requests and the casino’s exact responses.
8. Any responsible-gambling notice, self-exclusion request, affordability indicator, inducement, or account reopening evidence.
9. Game round IDs, provider names, session records, rules, RTP representation, and technical records relevant to the manipulation allegation.

## Continuation rule

Start from the newest canonical case status, not this baseline, whenever both exist. Convert newly verified baseline items into evidence-backed facts, retain contradicted items with a conflict label, and keep unknowns visible rather than silently resolving them.
