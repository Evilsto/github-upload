# Canonical deliverables and handoff

## Reuse before creating

Search the available case location for existing canonical files. Preserve their naming and structure when usable. Do not create “final-v2-new-revised” duplicates. If a format must change, document the superseded file and migrate its unique content.

## Canonical case set

Maintain only the files needed for the current maturity of the case:

| Artifact | Purpose |
|---|---|
| `BETPANDA_MASTER_CASE_INDEX.md` | Executive source of truth, scope, parties, totals, strongest claims, gaps, and links to all case components. |
| `CASE_STATUS.md` | Current position, changes since last update, blockers, decisions needed, and top next actions. |
| `EVIDENCE_REGISTER.csv` | Stable evidence IDs, provenance, integrity, relevance, and limitations. |
| `evidence-manifest.json` | Machine-generated path, metadata, and SHA-256 inventory. |
| `CHRONOLOGY.csv` | Event-level timeline with original and normalized timestamps. |
| `FINANCIAL_LEDGER.csv` | Deposits, withdrawals, reversals, external confirmations, and recovery calculations. |
| `CLAIMS_MATRIX.csv` | Claim-to-evidence-to-remedy analysis, counterevidence, deadlines, and missing proof. |
| `ACTION_REGISTER.md` | Ranked owner, deadline, dependency, status, and expected outcome for each action. |
| `CORRESPONDENCE_INDEX.md` | Incoming and outgoing communications, delivery proof, deadlines, and follow-ups. |
| `DRAFTS/` | Recipient-specific drafts clearly marked as draft until authorized and sent. |

Do not create empty placeholders. Add an artifact only when it will contain real case data.

## Master index minimum

Keep the master index answer-first:

1. Last updated time and evidence cutoff.
2. Objective and requested remedy.
3. Executive conclusion with confidence and material caveats.
4. Parties, domains, accounts, operator, payment rails, and jurisdictions.
5. Reconciled disputed amounts and definitions.
6. Strongest claims and why they matter.
7. Material counterarguments and weaknesses.
8. Evidence coverage and unresolved conflicts.
9. Active deadlines and top actions.
10. Links or paths to canonical registers and drafts.

## Update protocol

For every material work session:

1. Record the evidence and research cutoff.
2. Add new artifacts without changing old IDs.
3. Update affected events, ledger entries, claims, and totals.
4. Record contradictions rather than overwriting inconvenient facts.
5. Mark completed actions with outcome and evidence ID.
6. Re-rank next actions based on deadlines and new evidence.
7. Summarize exactly what changed.

Use ISO dates (`YYYY-MM-DD`) and UTC for normalized time while retaining the original timezone. Use decimal-safe arithmetic for money and tokens. Preserve source-language quotations and attach translations as derivatives.

## Quality gate

Before calling an artifact ready:

- Verify that every material factual statement maps to evidence or an uncertainty label.
- Reconcile totals to ledger rows and show exclusions.
- Check names, domains, account IDs, transaction IDs, dates, currencies, networks, and timezones.
- Confirm that links work or mark them inaccessible with the check date.
- Verify current laws, registers, addresses, complaint forms, and deadlines from authoritative sources.
- Remove duplicate allegations and unsupported adjectives.
- Include counterevidence, likely defenses, and enforcement limitations.
- Mask unnecessary personal data and secrets.
- Render and visually inspect PDF or office-document outputs when layout matters.
- Keep drafts separate from sent correspondence and preserve delivery receipts.

## User handoff

Lead with:

1. Current conclusion.
2. Recovery impact.
3. Files or evidence added.
4. Critical gap or risk.
5. The top three actions in order, with the first one immediately executable.

Avoid vague “continue investigating” tasks. State the target, source, output, and completion condition for each action.
